package simulator.control;

@SuppressWarnings("serial")
public class CmpException extends Exception{
	public CmpException(String txt) {
		super(txt);
	}
}
